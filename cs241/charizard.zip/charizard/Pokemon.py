class Score:

  def __init__(self, player_name):
    # The required attributes
    self._player_name = player_name
    self._current_score = 0
    self._current_level = 0
    self._current_multiplier = 1
    self._lives_remaining = 3

  # The required methods
  def add_points(self, amount):
    # implement this method by adding the number of points
    # specified by amount times the currentMultiplier value
    # to the currentScore. If the new score value should
    # result in the level changing, then change currentLevel.
    # return the new value of currentScore.
    if amount < 0:   #check for negative numbers
      return  self._current_score
    self._current_score += amount * self._current_multiplier    # Multiply point input by the current multiplier
    if self._current_score > (2**self._current_level * 10000) - 1:     # Initialize level at 0.
      level = 0
      while self._current_score > (2**level * 10000) - 1 or self._current_score < ((2** (level - 1)) * 10000) - 1:
        level += 1
      self._current_level = level
      return self._current_score

  def subtract_points(self, amount):
    # reset currentMultiplier to 1. subtract the number of
    # points specified by amount from currentScore, and update
    # currentLevel if necessary.
    # return the new value of currentScore.
    if amount < 0:    #check for negative numbers
      return self._current_score
    self._current_multiplier = 1             # Set multiplier to 1 when subtracting points
    self._current_score -= amount            # Subtract amount from the current score
    if self._current_score <= 0:             # Ensure that score does not go below 0 and set current level to 0 if score is 0
      self._current_score = 0
      self._current_level = 0
    elif self._current_score < (2**(self._current_level - 1) * 10000) - 1:
      level = self._current_level
      while self._current_score <= (2**(level - 1) *10000) - 1:
        level -= 1
      self._current_level = level
    return self._current_score

  def get_player_name(self):
    # return the name of the player associated with this object.
    return self._player_name

  def get_multiplier(self):
    # return the current value of the multiplier attribute.
    return self._current_multiplier


  def increment_multiplier(self):
    # increase the value of currentMultiplier by one.
    # return the new value of currentMultiplier.
    self._current_multiplier += 1
    return self._current_multiplier

  def get_score(self):
    # return the current value of the score attribute.
    return self._current_score

  def get_level(self):
    # return the current value of the level attribute.
    return self._current_level

  def get_lives(self):
    # return the number of lives remaining.
    return self._lives_remaining

  def lose_life(self):
    # decrement the number of lives remaining. If, after you
    # have decremented the lives attributes, that attribute
    # has a positive value, return True, indicating play can
    # continue. If the number is zero, return false,
    # indicating that the game is over.
    if self._lives_remaining > 0:   # ensure you can't have negative lives
      self._lives_remaining -= 1
    return self._lives_remaining > 0

  def gain_life(self):
    # increase the current value of the lives attribute
    # by one.
    self._lives_remaining += 1

  def __str__(self):
    return self._player_name + ' SCORE: ' + str(self._current_score) +\
        ' LVL: '+ str(self._current_level) +\
        ' MULT: ' + str(self._current_multiplier) +\
        ' LIVES: ' + str(self._lives_remaining)

class Scoreboard:

  def __init__(self, capacity):
    self._capacity = capacity
    self._high_scores = [None] * capacity
    self._entries = 0

  def update(self, candidate_score):
    # if candidate_score has a score value higher than the
    # lowest score in the Scoreboard, add it at the correct position.
    if self._entries == 0:
      self._high_scores[0] = candidate_score
      self._entries += 1
    elif self._high_scores[self._entries] == None or candidate_score.get_score() > self._high_scores[self._entries].get_score():
      self._high_scores[self._entries] = candidate_score
      if self._entries < self._capacity - 1:
        self._entries += 1
      self._sort()

  def _sort(self):
    for i in range(len(self._high_scores)):
      for j in range(i +1, len(self._high_scores)):
        if self._high_scores[j] != None and self._high_scores[j].get_score() > self._high_scores[i].get_score():
          tmp = self._high_scores[i]
          self._high_scores[i] = self._high_scores[j]
          self._high_scores[j] = tmp

  def print_scoreboard(self):
    # take advantage of the fact that the Score object implements
    # the __str__() method, and can therefore be passed directly to
    # print(). Use this to print the current score board.
    print(self.__str__())

  def __str__(self):
    output = ""
    for player in self._high_scores:
      if player != None:
        output += "Player Name: " + player.get_player_name() + ' - Score: ' + str(player.get_score()) + '\n'
    return output

if __name__ == '__main__':
  # your test code goes here
  # Create multiple Score objects, 
  # Test the methods thoroughly.
  # Be careful not to make assumptions
  # about how the methods behave or what
  # order things happen in.
  #
  # Finally, create a Scoreboard instance and
  # add your score objects to it, printing it 
  # each time to ensure that they are ordered
  # correctly.

  # player testing
  player1 = Score('p1')
  player2 = Score('p2')
  player3 = Score('p3')
  player4 = Score('p4')

  
  
  print('-'*50, '\n', 'Player Instance Tests\n', '-'*50)
  
  print('\nCannot subtract points before adding points:')
  print('- subtract 100000 points')
  player1.subtract_points(100000)
  print(player1.get_score(), ' - ', 0, 'are equal')
  
  player1.add_points(20000)
  player2.add_points(90000)
  player3.add_points(80000)
  player4.add_points(40000)  
  print('\npoints added are points returned:')
  print('- add some points to our players')
  print('player1 ->', player1.get_score(), ' - ', 20000, 'are equal')
  print('player2 ->', player2.get_score(), ' - ', 90000, 'are equal')
  print('player3 ->', player3.get_score(), ' - ', 80000, 'are equal')
  print('player4 ->', player4.get_score(), ' - ', 40000, 'are equal')
  
  print('\nTest point subtraction')
  print('- subract 50000 from all players')
  for player in [player1, player2, player3, player4]:
    player.subtract_points(50000)
  print('player1 ->', player1.get_score(), ' - ', 0, 'are equal')
  print('player2 ->', player2.get_score(), ' - ', 40000, 'are equal')
  print('player3 ->', player3.get_score(), ' - ', 30000, 'are equal')
  print('player4 ->', player4.get_score(), ' - ', 0, 'are equal')
  
  print('-'*50)
  
  print('Remove life, add life, remove life in range 1-5, beginning at 3 Lives')
  for k in range(1,5):
    player1.lose_life()
    print('Remove One Life: ', player1.get_lives())
    player1.gain_life()
    print('Add One Life   : ', player1.get_lives())
    player1.lose_life()
    print('Remove One Life: ', player1.get_lives())  
  
  print('-'*50)
  
  
  # Multiplier Testing
  player1.increment_multiplier()
  player1.add_points(5000)
  print('-Increment multiplier, add 5000 points:')
  print('Multiplier Test, Expected output: 10000: ', player1.get_score())
  print('-Increment multiplier, add 10000 points:')
  player1.increment_multiplier()
  player1.add_points(10000)
  print('Multiplier Test 2, Expected output: 40000: ', player1.get_score())
  print('-Subtract 10000 points')  
  player1.subtract_points(10000)
  print('Reset multiplier when points are subtracted, Multipler: ',player1.get_multiplier())
  print('Score after subtracting points: ',player1.get_score())
    
  print('-'*50)
    
  s = Scoreboard(10)
  player5 = Score('p5')
  player6 = Score('p6')
  player7 = Score('p7')
  player8 = Score('p8')
  player9 = Score('p9')
  player10 = Score('p10')
  player11 = Score('p11')
  
  print('-'*50)
  print('Test if more players being added to the scoreboard will cause errors')
  print('-'*50)
  players = [player1, player2, player3, player4, player5, player6, \
             player7, player8, player9, player10, player11]
  pts = 0
  for p in players:
    pts += 10000
    p.add_points(pts)

  
  for i in players:
    s.update(i)
  s.print_scoreboard()
  
  print('-'*50)
  
  print('-'*50)
  print('Test for level incrementing and decrementing')
  print('-'*50)
  player = Score('level test player')
  print('player starts at level 0')
  print(player.get_level(), ' - ', 0, 'are equal')
  print('> add 9999 points')
  player.add_points(9999)
  print(player.get_level(), ' - ', 0, 'are equal')
  print('> add 1 point')
  player.add_points(1)
  print(player.get_level(), ' - ', 1, 'are equal')
  print('> add 10000')
  player.add_points(10000)
  print(player.get_level(), ' - ', 2, 'are equal')
  print('> add 20000')
  player.add_points(20000)
  print(player.get_level(), ' - ', 3, 'are equal')
  player.add_points(1000000)
  print('> add 100000 ---> Current Score: ', player.get_score())
  print(player.get_level(), ' - ', 7, 'are equal')
  print('Being decrementing levels')
  print('>Subtract 500000 Points')
  player.subtract_points(500000)
  print(player.get_level(), ' - ', 6, 'are equal')
  print('> Subtract 300000')
  player.subtract_points(300000)  
  print(player.get_level(), ' - ', 5, 'are equal')
  print('> Subtract 150000')
  player.subtract_points(150000)
  print(player.get_level(), ' - ', 4, 'are equal')  
  print(' ---> Current Score: ', player.get_score())
  print('> Subtract 80001')
  player.subtract_points(80001)
  print('Current Score: ', player.get_score())
  print(player.get_level(), ' - ', 0, 'are equal')
  
  print('-'*50)